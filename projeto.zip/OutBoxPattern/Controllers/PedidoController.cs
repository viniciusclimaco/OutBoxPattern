﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using OutBoxPattern.Command;
using OutBoxPattern.Mediator;
using System.Threading.Tasks;

namespace OutBoxPattern.Controllers
{
    public class PedidoController : Controller
    {

        private readonly IMediatorHandler _mediator;

        public PedidoController(IMediatorHandler mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("pedido")]
        public async Task<IActionResult> CriarPedido(CriarPedidoCommand pedido)
        {            
            var result = await _mediator.EnviarComando(pedido);
            if (result.IsValid)
                return Ok();
            return BadRequest(result);
        }
    }
}
