﻿using MediatR;
using System;
using OutBoxPattern.Mediator;

namespace OutBoxPattern.Command
{
    public class CriarPedidoCommand : OutBoxPattern.Mediator.Command, IRequest<bool>
    {   
        public string Produto { get; set; }
        public decimal Desconto { get; set; }
        public decimal ValorTotal { get; set; }        
    }
}
